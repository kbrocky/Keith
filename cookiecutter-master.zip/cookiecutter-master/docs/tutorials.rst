====================
Additional Tutorials
====================

Learn How to Use Cookiecutter
-----------------------------

* :doc:`tutorial1` by `@audreyr`_


Create Your Very Own Cookiecutter Project Template
--------------------------------------------------

* :doc:`tutorial2` by `@audreyr`_

* `Project Templates Made Easy`_ by `@pydanny`_

* Cookiedozer Tutorials by `@hackebrot`_

  * Part 1: `Create Your Own Cookiecutter`_
  * Part 2: `Extending Cookiedozer`_
  * Part 3: `Wrapping up Cookiedozer`_


.. _`Project Templates Made Easy`: http://www.pydanny.com/cookie-project-templates-made-easy.html
.. _`Create Your Own Cookiecutter`: http://www.hackebrot.de/python/create-your-own-cookiecutter/
.. _`Extending Cookiedozer`: http://www.hackebrot.de/python/extending-cookiedozer/
.. _`Wrapping up Cookiedozer`: http://www.hackebrot.de/python/wrapping-up-cookiedozer/

.. _`@audreyr`: https://github.com/audreyr
.. _`@pydanny`: https://github.com/pydanny
.. _`@hackebrot`: https://github.com/hackebrot
