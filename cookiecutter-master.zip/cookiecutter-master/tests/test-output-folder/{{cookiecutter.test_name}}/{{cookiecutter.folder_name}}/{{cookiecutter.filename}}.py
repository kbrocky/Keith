print("This is the contents of {{ cookiecutter.filename }}.py.")
