{{cookiecutter.project_slug}}
{% for _ in cookiecutter.project_slug %}={% endfor %}

{{cookiecutter.foobar}}

https://github.com/{{cookiecutter.github_username}}/{{cookiecutter.project_slug}}
