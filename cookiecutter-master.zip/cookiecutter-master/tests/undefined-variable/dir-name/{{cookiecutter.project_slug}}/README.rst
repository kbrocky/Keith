{{cookiecutter.project_slug}}
{% for _ in cookiecutter.project_slug %}={% endfor %}
